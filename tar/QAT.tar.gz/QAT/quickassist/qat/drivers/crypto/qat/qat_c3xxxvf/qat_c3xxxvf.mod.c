#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x28950ef1, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0x402b8281, __VMLINUX_SYMBOL_STR(__request_module) },
	{ 0x98ab5c8d, __VMLINUX_SYMBOL_STR(kmalloc_caches) },
	{ 0x9f13414d, __VMLINUX_SYMBOL_STR(debugfs_create_dir) },
	{ 0xc2f7c1b1, __VMLINUX_SYMBOL_STR(pci_read_config_byte) },
	{ 0x7ae5ad74, __VMLINUX_SYMBOL_STR(sme_active) },
	{ 0x59d5a7f7, __VMLINUX_SYMBOL_STR(dma_set_mask) },
	{ 0x1c3e657e, __VMLINUX_SYMBOL_STR(pci_disable_device) },
	{ 0x1e866c04, __VMLINUX_SYMBOL_STR(adf_vf2pf_init) },
	{ 0x54923c32, __VMLINUX_SYMBOL_STR(adf_dev_init) },
	{ 0xc0a3d105, __VMLINUX_SYMBOL_STR(find_next_bit) },
	{ 0x20a7af80, __VMLINUX_SYMBOL_STR(adf_vf2pf_shutdown) },
	{ 0x715d7432, __VMLINUX_SYMBOL_STR(adf_enable_vf2pf_comms) },
	{ 0x31e556c3, __VMLINUX_SYMBOL_STR(adf_vf_isr_resource_free) },
	{ 0xffb4124b, __VMLINUX_SYMBOL_STR(adf_devmgr_update_class_index) },
	{ 0xcf73ce21, __VMLINUX_SYMBOL_STR(pci_release_regions) },
	{ 0x41f21c0c, __VMLINUX_SYMBOL_STR(adf_flush_vf_wq) },
	{ 0x399fb6a7, __VMLINUX_SYMBOL_STR(adf_dev_stop) },
	{ 0x85166c13, __VMLINUX_SYMBOL_STR(adf_devmgr_rm_dev) },
	{ 0x636c619f, __VMLINUX_SYMBOL_STR(debugfs_remove_recursive) },
	{ 0xf432dd3d, __VMLINUX_SYMBOL_STR(__init_waitqueue_head) },
	{ 0xbe4a1520, __VMLINUX_SYMBOL_STR(pci_set_master) },
	{ 0x1643bf7a, __VMLINUX_SYMBOL_STR(adf_dev_shutdown) },
	{ 0xe20aa1d2, __VMLINUX_SYMBOL_STR(adf_cfg_dev_add) },
	{ 0x127b8725, __VMLINUX_SYMBOL_STR(pci_iounmap) },
	{ 0xd795224, __VMLINUX_SYMBOL_STR(dev_err) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0x4c48a854, __VMLINUX_SYMBOL_STR(debugfs_remove) },
	{ 0x60d56ec5, __VMLINUX_SYMBOL_STR(adf_cfg_dev_remove) },
	{ 0xd8aa146, __VMLINUX_SYMBOL_STR(adf_pfvf_debugfs_add) },
	{ 0x1ebfe964, __VMLINUX_SYMBOL_STR(adf_devmgr_add_dev) },
	{ 0x62c89ae, __VMLINUX_SYMBOL_STR(adf_cfg_set_asym_rings_mask) },
	{ 0x15455c9c, __VMLINUX_SYMBOL_STR(pci_select_bars) },
	{ 0xb3ea49f2, __VMLINUX_SYMBOL_STR(kmem_cache_alloc_node_trace) },
	{ 0xc04d3f5f, __VMLINUX_SYMBOL_STR(adf_disable_vf2pf_comms) },
	{ 0xbdad1e89, __VMLINUX_SYMBOL_STR(adf_dev_start) },
	{ 0xf0fdf6cb, __VMLINUX_SYMBOL_STR(__stack_chk_fail) },
	{ 0x2ea2c95c, __VMLINUX_SYMBOL_STR(__x86_indirect_thunk_rax) },
	{ 0xebfdcb96, __VMLINUX_SYMBOL_STR(pci_read_config_dword) },
	{ 0xbdfb6dbb, __VMLINUX_SYMBOL_STR(__fentry__) },
	{ 0x2cb61da5, __VMLINUX_SYMBOL_STR(pci_unregister_driver) },
	{ 0xf26e1bf3, __VMLINUX_SYMBOL_STR(adf_disable_pf2vf_interrupts) },
	{ 0x8853043f, __VMLINUX_SYMBOL_STR(adf_config_device) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0xcc3b167a, __VMLINUX_SYMBOL_STR(adf_clean_vf_map) },
	{ 0xc3fc2f, __VMLINUX_SYMBOL_STR(pci_request_regions) },
	{ 0x7a7f7d68, __VMLINUX_SYMBOL_STR(dma_supported) },
	{ 0x99487493, __VMLINUX_SYMBOL_STR(__pci_register_driver) },
	{ 0xb352177e, __VMLINUX_SYMBOL_STR(find_first_bit) },
	{ 0x43b38448, __VMLINUX_SYMBOL_STR(dev_warn) },
	{ 0xd82954a4, __VMLINUX_SYMBOL_STR(adf_devmgr_pci_to_accel_dev) },
	{ 0x28318305, __VMLINUX_SYMBOL_STR(snprintf) },
	{ 0x8055d058, __VMLINUX_SYMBOL_STR(pci_iomap) },
	{ 0xdcb7bf12, __VMLINUX_SYMBOL_STR(adf_vf_isr_resource_alloc) },
	{ 0x46734db7, __VMLINUX_SYMBOL_STR(pci_enable_device) },
	{ 0x17fbce60, __VMLINUX_SYMBOL_STR(sme_me_mask) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=intel_qat";

MODULE_ALIAS("pci:v00008086d000019E3sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "282A4D823949CEC731CE100");
MODULE_INFO(rhelversion, "7.6");
#ifdef RETPOLINE
	MODULE_INFO(retpoline, "Y");
#endif
#ifdef CONFIG_MPROFILE_KERNEL
	MODULE_INFO(mprofile, "Y");
#endif
