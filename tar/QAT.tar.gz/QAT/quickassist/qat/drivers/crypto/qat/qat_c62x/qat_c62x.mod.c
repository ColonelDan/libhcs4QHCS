#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x28950ef1, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0x42393143, __VMLINUX_SYMBOL_STR(adf_check_slice_hang) },
	{ 0x402b8281, __VMLINUX_SYMBOL_STR(__request_module) },
	{ 0x98ab5c8d, __VMLINUX_SYMBOL_STR(kmalloc_caches) },
	{ 0x71864a2b, __VMLINUX_SYMBOL_STR(adf_disable_arb) },
	{ 0xdd0c0d4e, __VMLINUX_SYMBOL_STR(adf_pf_enable_vf2pf_comms) },
	{ 0x9f13414d, __VMLINUX_SYMBOL_STR(debugfs_create_dir) },
	{ 0xc2f7c1b1, __VMLINUX_SYMBOL_STR(pci_read_config_byte) },
	{ 0x7ae5ad74, __VMLINUX_SYMBOL_STR(sme_active) },
	{ 0x59d5a7f7, __VMLINUX_SYMBOL_STR(dma_set_mask) },
	{ 0x1c3e657e, __VMLINUX_SYMBOL_STR(pci_disable_device) },
	{ 0x76650cc3, __VMLINUX_SYMBOL_STR(adf_dev_quiesce) },
	{ 0x54923c32, __VMLINUX_SYMBOL_STR(adf_dev_init) },
	{ 0xc0a3d105, __VMLINUX_SYMBOL_STR(find_next_bit) },
	{ 0xcf73ce21, __VMLINUX_SYMBOL_STR(pci_release_regions) },
	{ 0x399fb6a7, __VMLINUX_SYMBOL_STR(adf_dev_stop) },
	{ 0x85166c13, __VMLINUX_SYMBOL_STR(adf_devmgr_rm_dev) },
	{ 0xe21dd372, __VMLINUX_SYMBOL_STR(adf_init_arb) },
	{ 0xc1a946b6, __VMLINUX_SYMBOL_STR(adf_set_ssm_wdtimer) },
	{ 0xbe4a1520, __VMLINUX_SYMBOL_STR(pci_set_master) },
	{ 0x1643bf7a, __VMLINUX_SYMBOL_STR(adf_dev_shutdown) },
	{ 0x9280b46d, __VMLINUX_SYMBOL_STR(adf_disable_aer) },
	{ 0xe20aa1d2, __VMLINUX_SYMBOL_STR(adf_cfg_dev_add) },
	{ 0x127b8725, __VMLINUX_SYMBOL_STR(pci_iounmap) },
	{ 0xd795224, __VMLINUX_SYMBOL_STR(dev_err) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0xd91117d4, __VMLINUX_SYMBOL_STR(adf_isr_resource_alloc) },
	{ 0xb7fe2eaf, __VMLINUX_SYMBOL_STR(adf_get_heartbeat_status) },
	{ 0x3a72f8d7, __VMLINUX_SYMBOL_STR(adf_clock_debugfs_add) },
	{ 0x4c48a854, __VMLINUX_SYMBOL_STR(debugfs_remove) },
	{ 0xa43e237a, __VMLINUX_SYMBOL_STR(adf_dev_measure_clock) },
	{ 0x828a70d2, __VMLINUX_SYMBOL_STR(adf_print_err_registers) },
	{ 0x60d56ec5, __VMLINUX_SYMBOL_STR(adf_cfg_dev_remove) },
	{ 0x925b029e, __VMLINUX_SYMBOL_STR(adf_disable_sriov) },
	{ 0x911b2c95, __VMLINUX_SYMBOL_STR(adf_reset_flr) },
	{ 0xcfc25da1, __VMLINUX_SYMBOL_STR(adf_isr_resource_free) },
	{ 0x99525331, __VMLINUX_SYMBOL_STR(adf_pf_disable_vf2pf_comms) },
	{ 0x1ebfe964, __VMLINUX_SYMBOL_STR(adf_devmgr_add_dev) },
	{ 0x62c89ae, __VMLINUX_SYMBOL_STR(adf_cfg_set_asym_rings_mask) },
	{ 0x15455c9c, __VMLINUX_SYMBOL_STR(pci_select_bars) },
	{ 0xb3ea49f2, __VMLINUX_SYMBOL_STR(kmem_cache_alloc_node_trace) },
	{ 0xbdad1e89, __VMLINUX_SYMBOL_STR(adf_dev_start) },
	{ 0xf0fdf6cb, __VMLINUX_SYMBOL_STR(__stack_chk_fail) },
	{ 0x193a0ad4, __VMLINUX_SYMBOL_STR(adf_sriov_configure) },
	{ 0xd4f94737, __VMLINUX_SYMBOL_STR(adf_enable_aer) },
	{ 0x372978e4, __VMLINUX_SYMBOL_STR(adf_send_admin_init) },
	{ 0xb7869283, __VMLINUX_SYMBOL_STR(adf_init_admin_comms) },
	{ 0x2ea2c95c, __VMLINUX_SYMBOL_STR(__x86_indirect_thunk_rax) },
	{ 0xebfdcb96, __VMLINUX_SYMBOL_STR(pci_read_config_dword) },
	{ 0x29488549, __VMLINUX_SYMBOL_STR(qat_crypto_dev_config) },
	{ 0xbdfb6dbb, __VMLINUX_SYMBOL_STR(__fentry__) },
	{ 0x2cb61da5, __VMLINUX_SYMBOL_STR(pci_unregister_driver) },
	{ 0x7dd871a6, __VMLINUX_SYMBOL_STR(adf_configure_iov_threads) },
	{ 0xf99d347e, __VMLINUX_SYMBOL_STR(node_states) },
	{ 0x8853043f, __VMLINUX_SYMBOL_STR(adf_config_device) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0xc3fc2f, __VMLINUX_SYMBOL_STR(pci_request_regions) },
	{ 0x7a7f7d68, __VMLINUX_SYMBOL_STR(dma_supported) },
	{ 0x99487493, __VMLINUX_SYMBOL_STR(__pci_register_driver) },
	{ 0xb352177e, __VMLINUX_SYMBOL_STR(find_first_bit) },
	{ 0x4cbbd171, __VMLINUX_SYMBOL_STR(__bitmap_weight) },
	{ 0x43b38448, __VMLINUX_SYMBOL_STR(dev_warn) },
	{ 0xd82954a4, __VMLINUX_SYMBOL_STR(adf_devmgr_pci_to_accel_dev) },
	{ 0x6e4430f9, __VMLINUX_SYMBOL_STR(adf_exit_admin_comms) },
	{ 0xa16f7553, __VMLINUX_SYMBOL_STR(adf_cfg_get_services_enabled) },
	{ 0x28318305, __VMLINUX_SYMBOL_STR(snprintf) },
	{ 0x8055d058, __VMLINUX_SYMBOL_STR(pci_iomap) },
	{ 0x808f3a4, __VMLINUX_SYMBOL_STR(adf_exit_arb) },
	{ 0x46734db7, __VMLINUX_SYMBOL_STR(pci_enable_device) },
	{ 0x5caa678d, __VMLINUX_SYMBOL_STR(adf_cfg_gen_dispatch_arbiter) },
	{ 0x53108e44, __VMLINUX_SYMBOL_STR(pci_save_state) },
	{ 0x17fbce60, __VMLINUX_SYMBOL_STR(sme_me_mask) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=intel_qat";

MODULE_ALIAS("pci:v00008086d000037C8sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "7A7DAF30E857A9E22EAE9EC");
MODULE_INFO(rhelversion, "7.6");
#ifdef RETPOLINE
	MODULE_INFO(retpoline, "Y");
#endif
#ifdef CONFIG_MPROFILE_KERNEL
	MODULE_INFO(mprofile, "Y");
#endif
